create view view_comentario_usuario as
  SELECT c.id, c.comentario, c.fk_avaliacao, a.fk_usuario
  FROM (comentario c
      JOIN avaliacao a ON ((a.id = c.fk_avaliacao)));

alter table view_comentario_usuario
  owner to postgres;

