create function get_comentario_por_usuario(usuario_id integer)
  returns TABLE(id integer, comentario character varying, fk_avaliacao integer, fk_usuario integer)
language plpgsql
as $$
BEGIN
	RETURN QUERY
	SELECT
		c.id AS comentario_id,
		c.comentario comentario_comentario,
		c.fk_avaliacao comentario_fk_avaliacao,
		a.fk_usuario avaliacao_fk_usuario
	FROM comentario AS c
	INNER JOIN avaliacao AS a ON a.id = c.fk_avaliacao
	WHERE a.fk_usuario = usuario_id;
END;
$$;

alter function get_comentario_por_usuario(integer)
  owner to postgres;

